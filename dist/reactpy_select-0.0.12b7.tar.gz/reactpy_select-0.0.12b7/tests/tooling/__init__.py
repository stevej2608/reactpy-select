from .wait_stable import wait_page_stable

__all__ = ("wait_page_stable",)